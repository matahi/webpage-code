#################################################################
### Practical session: Machine learning for computational biology
#################################################################

##############################
### Don't forget to set the good directory
##############################

#setwd('PATH/TP_Kernels')

### Packages are already installed for the practical session 
### Otherwise, uncomment the following code.

# pkgs <- c( 'ggplot2', 'kernlab', 'ROCR' )
# install.packages( pkgs ) 

################
## A) Linear SVM
################

### A.1) Load the data
load('linear1.RData')

# This file contains:
# - linear1.train       : matrix of size n1 x 3 (first column is x1, second column is x2, third column is y)
# - linear1.test.input  : matrix of size n2 x 2 (first column is x1, second column is x2, y is unknown)
# - linear1.data        : aggregated info (train+test) for visualization purposes (see A.2)

### A.2) Visualize the data
require( 'ggplot2' )
qplot( data=linear1.data, x.1, x.2, colour=factor(y), shape=factor(train) )

### A.3) Train a linear SVM
require( 'kernlab' )
linear1.svm <- ksvm( y ~ ., data=linear1.train, type='C-svc', kernel='vanilladot',C=100, scale=c() )

### A.4) Plot the model
plot( linear1.svm, data=linear1.train )

### A.5) Adding points of test on the graph
points( linear1.test.input[ sample.int(nrow(linear1.test.input),10), ], pch=4 )

### A.6) Prediction
linear1.prediction <- predict( linear1.svm, linear1.test.input )

### A.7) Look at accuracy
load('linear1Sol.RData')
# contains linear1.test.output

print(paste0('Accuracy: ', floor(100*sum( linear1.prediction == linear1.test.output )/length(linear1.test.output)), '%'))


#################################
### A.8) Non-separable datasets and accuracy 
#################################

### A.9) load the data
load('linear2.RData')

# This file contains:
# - linear2.data
# - linear2.train
# - linear2.test.input

### A.10) Visualize the data
require( 'ggplot2' )
qplot( data=linear2.data, x.1, x.2, colour=factor(y), shape=factor(train) )

### A.11) Train a linear SVM
require( 'kernlab' )
linear2.svm <- ksvm( y ~ ., data=linear2.train, type='C-svc', kernel='vanilladot',C=100, scale=c() )

### A.12) Plot the model
plot( linear2.svm, data=linear2.train )

### A.13) Prediction
linear2.prediction <- predict( linear2.svm, linear2.test.input)

### A.14) Look at accuracy
load('linear2Sol.RData')
# contains linear2.test.output

print(paste0('Accuracy: ', floor(100*sum( linear2.prediction == linear2.test.output )/length(linear2.test.output)), '%'))

### A.15) A confusion matrix gives more information than just accuracy
print('Confusion Matrix: ');print(table( linear2.prediction, linear2.test.output, dnn= c("prediction","reality") ))

### A.16) Even better: ROC and Precision-Recall curves

linear2.prediction.score <- predict( linear2.svm, linear2.test.input, type='decision' )

require( 'ROCR' )

## ROC
linear2.roc.curve <- performance( prediction( linear2.prediction.score, linear2.test.output ), measure='tpr', x.measure='fpr' )
plot( linear2.roc.curve )

## Supplementary PR Curves
linear2.pr.curve <- performance( prediction( linear2.prediction.score, linear2.test.output ), measure='prec', x.measure='rec' )
plot( linear2.pr.curve )

##################################
###  B) Nonlinear SVM
##################################

### B.1) Load the data
load('nonlinear.RData')

### B.2) Visualize the data
qplot( data=nonlinear.data, x.1, x.2, colour=factor(y), shape=factor(train) )

### B.3) Let's still try a linear svm
badlinear.svm <- ksvm( y ~ ., data=nonlinear.train, type='C-svc', kernel='vanilladot', C=100, scale=c() )
plot( badlinear.svm, data=nonlinear.train )

### B.4) Ok try another one (RBF)
nonlinear.svm <- ksvm( y ~ ., data=nonlinear.train, type='C-svc', kernel='rbf', kpar=list(sigma=1), C=100, scale=c() )
plot( nonlinear.svm, data=nonlinear.train )


### B.5) Look at the effect of C on the model
require('manipulate')
manipulate( plot( ksvm( y ~ ., data=nonlinear.train, type='C-svc', kernel=k, C=2^c.exponent, scale=c() ), data=nonlinear.train ), c.exponent=slider(-10,10),
                  k=picker('Gaussian'='rbfdot', 'Linear'='vanilladot', 'Hyperbolic'='tanhdot','Spline'='splinedot', 'Laplacian'='laplacedot') )

### B.6) Bias-Variance Tradeoff
BiasVarianceTradeoff <- function( dataset, cross=10, c.seq=2^seq(-10, 10), ... ) {
  err <- sapply( c.seq, function( c ) 
                {
                        cross( ksvm( y ~ ., data=dataset, C=c, cross=cross, ...) )
                })
  return(data.frame( c=c.seq, error=err ))
}

qplot( c, error, data=BiasVarianceTradeoff( nonlinear.train, type='C-svc', kernel='rbfdot' ), geom='line', log='x' )

###################################################
###  C) Supplementary: Real data analysis
###################################################
source( 'http://bioconductor.org/biocLite.R' )
biocLite( 'ALL' )

require( 'ALL' )
data( 'ALL' ) ## contains the "ALL" dataset

## Preprocessing of the data:
all.features <- t(exprs(ALL))  ## matrix of size (n=128 x p=12625) containing gene expression profiles of patients with Acute lymphoblastic leukemia.
all.class_binary <- substr( ALL$BT, 1, 1 ) ## output y (2 classes) (classification of leukemia: B-cell ALL vs T-cell ALL).

### C.1: Can we train a classifier that separate with a good accuracy B-cell leukemia from T-cell leukemia ?

###########
### Remark: 
###########
### In section A and B) the input and output were combined into the same variable (the last column of the data.frame was the output).
### Here we separated the design matrix a.k.a the input X as a variable "all.features" and the output "all.class_binary"           
### You can adapt the code for ksvm in A and B): instead of doing ksvm(y~., data= dataset, ...) you have to do ksvm(x=all.features,y=all.class_binary, ...)

### Note: As explained earlier, Accuracy is important but ROC curves illustrate better the performance of the algorithm... 

#######
### C.2: How can you derive from what you learned a classifier that can predict more than 2 classes?
all.class <- ALL$BT ## output y (several classes)







